# Terrorism Prediction Map

Predict and visualize terrorism activity using GTD dataset.